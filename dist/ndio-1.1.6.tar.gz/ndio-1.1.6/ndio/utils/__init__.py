"""
Utility functions common to all ndio submodules.
"""
